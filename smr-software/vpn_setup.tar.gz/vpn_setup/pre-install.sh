#!/bin/bash

echo
echo "*************************************************"
echo "set timezone"
echo "*************************************************"
sleep 1
sudo dpkg-reconfigure tzdata

echo
echo "*************************************************"
echo "set keyboard"
echo "*************************************************"
sleep 1
sudo dpkg-reconfigure keyboard-configuration

echo
echo "*************************************************"
echo "set default resolution 1080p"
echo "*************************************************"
sleep 1
sudo raspi-config nonint do_resolution 1 16
#sudo sed -i '$ a hdmi_force_hotplug=1' /boot/config.txt
#sudo sed -i '$ a hdmi_group=1' /boot/config.txt
#sudo sed -i '$ a hdmi_mode=16' /boot/config.txt

echo
echo "*************************************************"
echo "change default password"
echo "*************************************************"
sleep 1

old_pwd=raspberry
new_pwd=smboston
(echo $old_pwd ;  echo $new_pwd ; echo $new_pwd) | passwd

echo 
echo "*************************************************"
echo "apt-get update"
echo "*************************************************"
sleep 1
sudo apt-get -y update
	
echo 
echo "*************************************************"
echo "apt-get upgrade"
echo "*************************************************"
sleep 1
sudo apt-get -y upgrade
	
echo 
echo "*************************************************"
echo "apt-get update"
echo "*************************************************"
sleep 1
sudo apt-get -y update

echo 
echo "*************************************************"
echo "clean up downloaded packages"
echo "*************************************************"
sleep 1
sudo apt-get clean

echo 
echo "*************************************************"
echo "add wifi country code"
echo "*************************************************"
sleep 1
sudo raspi-config nonint do_wifi_country US
#sudo sed -i '$ a country=US' /etc/wpa_supplicant/wpa_supplicant.conf
#sudo iw reg set US
#sudo rfkill unblock wifi

echo 
echo "*************************************************"
echo "enable ssh  for PI"
echo "*************************************************"
sleep 1
sudo raspi-config nonint do_ssh 0
#sudo systemctl enable ssh
#sudo systemctl start ssh

echo 
echo "*************************************************"
echo "enable vnc  for PI"
echo "*************************************************"
sleep 1

sudo raspi-config nonint do_vnc 0
#sudo systemctl enable vncserver-x11-serviced.service
#sudo systemctl start vncserver-x11-serviced.service

echo 
echo "*************************************************"
echo "enable predictable network interface names"
echo "*************************************************"
sleep 1
sudo raspi-config nonint do_net_names 0

echo "settings will not be enabled till after reboot"

echo
read -p "Do you want to REBOOT?" -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]
then 
    [[ "$0" = "$BASH_SOURCE" ]] && exit 1 || return 1
fi

sudo reboot

