#!/bin/bash

sleep 60

#sudo iptables -t nat -A POSTROUTING -o tun0 -j MASQUERADE

#current_dir=$(pwd)
#script_dir=$(dirname $0)
#echo $current_dir
#echo $script_dir
total_dir="/etc/openvpn/server"
echo "Install Directory=$total_dir"

#load in defaults from config file
. $total_dir/iptablesConfig.sh

#echo "anything not in local ipaddress range: $LOCAL_SUBNET goes to $VPN_IPADDRESS"
#sudo iptables -t nat -A POSTROUTING  ! -d "$LOCAL_SUBNET" -j SNAT --to "$VPN_IPADDRESS"

	# forward vpn addresses to vpn network
    sudo iptables -t nat -A POSTROUTING  -d 10.8.0.0/24  -j SNAT --to "$VPN_IPADDRESS"
    sudo iptables -t nat -A POSTROUTING  -d 192.168.10.0/24  -j SNAT --to 192.168.10.61
    
    #allow outgoing ip from internal network to go to external network(internet access)
    #iptables -A FORWARD -i enp2s0 -o enp1s0 -j ACCEPT
    #iptables -A FORWARD -i enp1s0 -o enp2s0 -m state --state ESTABLISHED,RELATED -j ACCEPT
    #iptables -t nat -A POSTROUTING -o enp1s0 -j MASQUERADE


echo "ports = ${PORTS[@]}"
for i in "${PORTS[@]}"
do
    echo "Forwarding port $i from $VPN_IPADDRESS to $LOCAL_HOST_IPADDRESS"
    sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport $i -j DNAT --to-destination "$LOCAL_HOST_IPADDRESS"
    sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport $i -j DNAT --to-destination "$LOCAL_HOST_IPADDRESS"
done

# port forwarding for cameras
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8000 -j DNAT --to-destination 192.168.1.51
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8000 -j DNAT --to-destination 192.168.1.51
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8001 -j DNAT --to-destination 192.168.1.52:8000
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8001 -j DNAT --to-destination 192.168.1.52:8000
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8002 -j DNAT --to-destination 192.168.1.53:8000
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8002 -j DNAT --to-destination 192.168.1.53:8000
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8003 -j DNAT --to-destination 192.168.1.54:8000
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8003 -j DNAT --to-destination 192.168.1.54:8000
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8081 -j DNAT --to-destination 192.168.1.51:80
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8081 -j DNAT --to-destination 192.168.1.51:80
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8082 -j DNAT --to-destination 192.168.1.52:80
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8082 -j DNAT --to-destination 192.168.1.52:80
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8083 -j DNAT --to-destination 192.168.1.53:80
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8083 -j DNAT --to-destination 192.168.1.53:80
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport 8084 -j DNAT --to-destination 192.168.1.54:80
sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport 8084 -j DNAT --to-destination 192.168.1.54:80
