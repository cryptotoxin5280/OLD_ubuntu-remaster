#!/bin/bash
VPN_TYPE="<VPN_TYPE>"
# set ip address on vpn
case "$VPN_TYPE" in
	server)
		VPN_IPADDRESS="10.8.0.1"		
		;;
	client1)
		VPN_IPADDRESS="10.8.0.11"
		;;
	client2)
		VPN_IPADDRESS="10.8.0.12"
		;;
	client3)
		VPN_IPADDRESS="10.8.0.13"
		;;
	client4)
		VPN_IPADDRESS="10.8.0.14"
		;;
	client5)
		VPN_IPADDRESS="10.8.0.15"
		;;
	client6)
		VPN_IPADDRESS="10.8.0.16"
		;;

esac

echo "vpn ipaddress = $VPN_IPADDRESS"

# local subnet
LOCAL_SUBNET="192.168.0.0/16"

# local address to forward ports to
LOCAL_HOST_IPADDRESS="192.168.1.50"

# ports to forward
PORTS=(21 22 123 399 3306 9000 9001 9002 9003 9004 9300 9301 9302 9303 9304)