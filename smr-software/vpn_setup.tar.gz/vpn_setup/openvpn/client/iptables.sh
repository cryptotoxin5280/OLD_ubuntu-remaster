#!/bin/bash

sleep 60

#sudo iptables -t nat -A POSTROUTING -o tun0 -j MASQUERADE

#current_dir=$(pwd)
#script_dir=$(dirname $0)
#echo $current_dir
#echo $script_dir
total_dir="/etc/openvpn/client"
echo "Install Directory=$total_dir"

#load in defaults from config file
. $total_dir/iptablesConfig.sh

echo "anything not in local ipaddress range: $LOCAL_SUBNET goes to $VPN_IPADDRESS"
sudo iptables -t nat -A POSTROUTING  ! -d "$LOCAL_SUBNET" -j SNAT --to "$VPN_IPADDRESS"

echo "ports = ${PORTS[@]}"
for i in "${PORTS[@]}"
do
        echo "Forwarding port $i from $VPN_IPADDRESS to $LOCAL_HOST_IPADDRESS"
	sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p tcp --dport $i -j DNAT --to-destination "$LOCAL_HOST_IPADDRESS"
    sudo iptables -t nat -A PREROUTING -d "$VPN_IPADDRESS" -p udp --dport $i -j DNAT --to-destination "$LOCAL_HOST_IPADDRESS"
done