#!/bin/bash
current_dir=$(pwd)
script_dir=$(dirname $0)
#echo $current_dir
#echo $script_dir
total_dir=$current_dir'/'$script_dir

echo "Install Directory=$total_dir"

#load in defaults from config file
. $total_dir/installConfig.sh

echo
echo "*************************************************"
echo "apt-get install"
echo "*************************************************"
sleep 1
sudo apt-get -y install openvpn ftp


echo
echo "*************************************************"
echo "clean up downloaded packages"
echo "*************************************************"
sleep 1
sudo apt-get clean

if [[ $HARDWARE_TYPE = "pi" ]]
then

	echo
	echo "*************************************************"
	echo "disable onboard wifi  and bluetooth for pi"
	echo "*************************************************"
	sleep 1
	sudo sed -i '$ a dtoverlay=pi3-disable-wifi' /boot/config.txt
	sudo sed -i '$ a dtoverlay=pi3-disable-bt' /boot/config.txt

	echo
	echo "*************************************************"
	echo "set ipaddresses"
	echo "*************************************************"
	sleep 1

	# looking for nic with b8:27:eb:XX:XX:XX in name. this is upper mac
	# address for raspberry pi boards mac address
	pi_nic_mac="XX:XX:XX:XX:XX"
	usb_nic_mac="XX:XX:XX:XX:XX"
	pi_nic="eth0"
	usb_nic="eth1"

	D='/sys/class/net'
	for nic in $(ls $D)
	do
		if [[ $nic = *"en"* ]]; then
	        	echo $nic
			if grep -q "b8:27:eb" $D/$nic/address; then
				pi_nic_mac=$(<$D/$nic/address)
				pi_nic=$nic
			else
				usb_nic_mac=$(<$D/$nic/address)
				usb_nic=$nic
			fi
		fi
	done

	echo "raspberry pi nic = "$pi_nic
	echo "raspberry pi nic mac = "$pi_nic_mac
	echo "usb nic = "$usb_nic
	echo "raspberry pi nic mac = "$usb_nic_mac

	# set IP addresses
	echo "set IP addresses"
	sudo sed -i '$ a # Static IP Configuration for VPN module' /etc/dhcpcd.conf
	sudo sed -i "$ a interface $pi_nic" /etc/dhcpcd.conf
	sudo sed -i "$ a static ip_address=$ip_address_external_nic/24" /etc/dhcpcd.conf
	sudo sed -i '$ a # It is possible to fall back to a static IP if DHCP fails' /etc/dhcpcd.conf
	sudo sed -i '$ a # define static profile' /etc/dhcpcd.conf
	sudo sed -i "$ a profile static_$usb_nic" /etc/dhcpcd.conf
	sudo sed -i "$ a static ip_address=$ip_address_internal_nic/24" /etc/dhcpcd.conf
	sudo sed -i "$ a # fallback to static profile on $usb_nic" /etc/dhcpcd.conf
	sudo sed -i "$ a interface $usb_nic" /etc/dhcpcd.conf
	sudo sed -i "$ a fallback static_$usb_nic" /etc/dhcpcd.conf

else
	# set IP addresses
	echo "set IP addresses"
	#delete  current setting for adapter
	sudo sed -i "/enp/d" /etc/network/interfaces
	#put in new settings
	sudo sed -i "$ a # Static IP Configuration for VPN module" /etc/network/interfaces

	sudo sed -i "$ a # External interface(VPN)" /etc/network/interfaces
	sudo sed -i "$ a auto $name_external_nic" /etc/network/interfaces
	sudo sed -i "$ a iface $name_external_nic inet static" /etc/network/interfaces
	sudo sed -i "$ a   address $ip_address_external_nic" /etc/network/interfaces
	sudo sed -i "$ a   netmask 255.255.255.0" /etc/network/interfaces
	sudo sed -i "$ a   gateway 192.168.10.1" /etc/network/interfaces
	sudo sed -i "$ a   dns-nameservers 8.8.8.8 1.1.1.1" /etc/network/interfaces
	#sudo sed -i "$ a   gateway $ip_address_external_nic" /etc/network/interfaces

	sudo sed -i "$ a # Internal interface" /etc/network/interfaces
	sudo sed -i "$ a auto $name_internal_nic" /etc/network/interfaces
	sudo sed -i "$ a iface $name_internal_nic inet static" /etc/network/interfaces
	sudo sed -i "$ a   address $ip_address_internal_nic" /etc/network/interfaces
	sudo sed -i "$ a   netmask 255.255.255.0" /etc/network/interfaces
	#sudo sed -i "$ a   gateway $ip_address_external_nic" /etc/network/interfaces

	sudo sed -i "$ a # other interface" /etc/network/interfaces
	sudo sed -i "$ a allow-hotplug $name_other1_nic" /etc/network/interfaces
	sudo sed -i "$ a   iface $name_other1_nic inet dhcp" /etc/network/interfaces

	sudo sed -i "$ a # other2 interface" /etc/network/interfaces
	sudo sed -i "$ a allow-hotplug $name_other2_nic" /etc/network/interfaces
	sudo sed -i "$ a   iface $name_other2_nic inet dhcp" /etc/network/interfaces

	#comment out server config line for  openvpn version less than 2.4
	sed -i "s?explicit-exit-notify 1?;explicit-exit-notify 1?g"  "$total_dir"/openvpn/server/server.conf
	#comment out client config line for  openvpn version less than 2.4
	sed -i "s?connect-retry 5 60?;connect-retry 5 60?g"  "$total_dir"/openvpn/client/client.conf
	# added so  up script can run iptables on service startup
	sudo modprobe ip_tables
	sudo sed -i "$ a ip_tables" /etc/modules
	#comment out ip forwarding on client since everthing is done on client computer for beacon
	sed -i "s?up /etc/openvpn/client/iptables.sh?;up /etc/openvpn/client/iptables.sh?g"  "$total_dir"/openvpn/client/client.conf
	# want to change ssh port of vault(vpn box) to 2200
	sudo sed -i "s?Port 22?Port 2200?g"  /etc/ssh/sshd_config
    
fi
# set vpn config files
echo "set up vpn config files"
if [[ $VPN_TYPE = "server" ]]
then
        #change values in iptablesConfig.sh
	sed -i "s?<VPN_TYPE>?$VPN_TYPE?g"  "$total_dir"/openvpn/server/iptablesConfig.sh
	sed -i "s?<VPN_SERVER_IP_ADDRESS>?$VPN_SERVER_IP_ADDRESS?g" "$total_dir"/openvpn/server/server.conf
	# copy all files to /etc/openvpn directory
	sudo cp -r -f "$total_dir"/openvpn/server /etc/openvpn
	#copy conf file to directory to autostart on boot
	sudo cp -r -f  /etc/openvpn/server/server.conf /etc/openvpn

else
	#change values in client.conf
	sed -i "s?<VPN_TYPE>?$VPN_TYPE?g" "$total_dir"/openvpn/client/client.conf
	sed -i "s?<VPN_SERVER_IP_ADDRESS>?$VPN_SERVER_IP_ADDRESS?g" "$total_dir"/openvpn/client/client.conf
	#change values in iptablesConfig.sh
	sed -i "s?<VPN_TYPE>?$VPN_TYPE?g"  "$total_dir"/openvpn/client/iptablesConfig.sh
        # copy all files to /etc/openvpn directory
	sudo cp -r -f "$total_dir"/openvpn/client /etc/openvpn
	#copy conf file to directory to autostart on boot
	sudo cp -r -f  /etc/openvpn/client/client.conf /etc/openvpn
fi

# set enable ip forwarding
echo "enable ip forwarding"
sudo sed -i "s?#net.ipv4.ip_forward=1?net.ipv4.ip_forward=1?g" /etc/sysctl.conf

# ports for remote PLC access
echo "enable remote PLC access"
sudo apt install debconf-utils
echo iptables-persistent iptables-persistent/autosave_v4 boolean true | sudo debconf-set-selections
echo iptables-persistent iptables-persistent/autosave_v6 boolean true | sudo debconf-set-selections
sudo apt-get install -y iptables-persistent
sudo iptables -t nat -A PREROUTING -d 10.8.0.1 -p tcp --dport 102 -j DNAT --to-destination 192.168.1.10
sudo iptables -t nat -A POSTROUTING -d 192.168.1.10 -p tcp --dport 102 -j SNAT --to- 192.168.1.70
sudo iptables -t nat -A PREROUTING -d 192.168.1.70 -p tcp --dport 102 -j DNAT --to-destination 10.8.0.11
sudo netfilter-persistent save

# echo
# read -p "Do you want to REBOOT?" -n 1 -r
# echo
# if [[ ! $REPLY =~ ^[Yy]$ ]]
# then
#     [[ "$0" = "$BASH_SOURCE" ]] && exit 1 || return 1
# fi

sudo reboot

