# VPN server installation for Protectli Vault. 

## Hardware
- Find a (vga) cable and monitor and keyboard to use with protectli.
- Get or make USB 16.04 Server 64-bit install medium
- If necessary, use F11 to enter the boot menu
- Connect the protectli to the world wide web with an ethernet cable into the WAN port.

## Go through the Ubuntu 16.04 installation process.

enp1s0 is the port labeled WAN.

hostname: vpn-server. 

user: smr. 

password: random 12-char alphanumeric. STORE IN SPREADSHEET (linked below. 

Don't encrypt the device. 

Remember to set timezone to UTC later

guided; use whole disk

Install openssh server
  
## Install the vpn. 
Run:

    vpn-server$ ip a # note the ip
	your-computer$ rsync -aprvC vpn_setup/ smr@$VPN_IP_ADDR:~/vpn_setup

Do not run this blindly. Do take the time to look at these commands'
respective man pages if you do not understand how they are being used.

Edit `vpn\_setup/installConfig.sh` such that 
    
    VPN_TYPE="server"
	
Ensure a connection to the world wide web. 

    sudo ./install.sh # thank you, Marty. 
	
Reboot when finished. 

## Loose ends

Use this to set the timezone to UTC: 

    vpn-server$ sudo dpkg-reconfigure tzdata
	
If you haven't already done so, randomize the password: 

Easiest is to run the following interactive command: 

    vpn-server$ passwd
	
Another option is the following: 

    vpn-server$ USER_PASSWORD=$(cat /dev/urandom | tr -cd '[:alnum:]' | head -c 12)
	vpn-server$ echo $USER_PASSWORD
	vpn-server$ sudo su
	vpn-server# printf "smr:$USER_PASSWORD\n" | chpasswd

Finally, add the serial number and password to sharepoint, next to the
corresponding ac that will go in the same SM300 box:
[0001-SMR-LIS-0007.xlsx](https://seamachines.sharepoint.com/:x:/r/sites/SeaMachinesTeam/_layouts/15/Doc.aspx?sourcedoc={10822640-2537-4163-9260-7868743098ca}&action=default)
