## VPN System Map

```
[xxx.xxx.xxx.xxx] = real ip addresses of ethernet adapter
<xxx.xxx.xxx.xxx> = assigned vpn ip address


STEADFAST 4G MODEM                                                  LIGHTNING 4G MODEM
[LAN 192.168.10.1]                                                  [LAN 192.168.10.101]
        |                                                                  |
        |                                                                  |
        |                                                                  |
        |        RADIO LINK     /\    /\    /\    /\     RADIO LINK        |
        |-----[192.168.10.251] /  \  /  \  /  \  /  \ [192.168.10.252]-----|
        |                          \/    \/    \/                          |
        |                                                                  |
        |                                                                  |
        |------------|                                                     |------------|
        |            |                                                     |            |
        |       STEADFAST UI     <client1>                                 |       LIGHTNING UI     <client1>
        |      [192.168.10.62]  <10.8.0.11>                                |      [192.168.10.162] <10.8.0.11>
        |                                                                  |
        |                                                                  |
        |                                                                  |
        |------------|                                                     |------------|
        |            |                                                     |            |
        |      STEADFAST BEACON   <client2>                                |      LIGHTNING BEACON   <client2>
        |      [192.168.10.63]   <10.8.0.12>                               |      [192.168.10.163]  <10.8.0.12>
        |                                                                  |
        |                                                                  |
        |                                                                  |
 [WAN 192.168.10.61]  <vpn 10.8.0.1>                              [WAN 192.168.10.161]  <vpn 10.8.0.1>
 STEADFAST SM300 VPN   <vpn server>                               LIGHTNING SM300 VPN    <vpn server>
 [LAN 192.168.1.70]                                               [LAN 192.168.1.70]
        |                                                                  | 
        |                                                                  |
        |-----------------------------------|                              |-----------------------------------|
        |                 |                 |                              |                 |                 |
        |                 |                 |                              |                 |                 |
 [192.168.1.50]    [192.168.1.51]    [192.168.1.52]                 [192.168.1.50]    [192.168.1.51]    [192.168.1.52]
       AC              CAMERA 1          CAMERA 2                          AC             CAMERA 1          CAMERA 2
	   


	   
	   
	   
port(s)           decription          forward to         protocol
---------         --------------      ------------       --------

9000-9004         moos                192.168.1.50       udp/tcp
9300-9304         moos                192.168.1.50       udp/tcp
21                ftp                 192.168.1.50       udp/tcp
22                ssh                 192.168.1.50       udp/tcp
123               NTP                 192.168.1.50       udp/tcp
399               moos/mysql          192.168.1.50       udp/tcp
3306              MYSQL               192.168.1.50       udp/tcp
8000              camera 1 video      192.168.1.51:8000
8001              camera 2 video      192.168.1.52:8000




Notes:
------

- hardware types:
  pi =  rasberry pi running raspian 16.04
  intel = intel cpu (protectli-the vault)running ubuntu server 16.04.5 64-bit

- port 2200 is the ssh port for the protectli on vpn client and server

- be sure to enable ssh when installing ubuntu server on protectli

login: smr
pwd: smboston

```