#!/bin/bash
# hardware types:
#  pi =  rasberry pi running raspian 16.04
#  intel = intel cpu (protectli-the vault)running ubuntu server 16.04.5 64-bit
HARDWARE_TYPE="intel"
name_internal_nic="enp2s0"
name_external_nic="enp1s0"
name_other1_nic="enp3s0"
name_other2_nic="enp4s0"

# vpn client types: server, client1, client2, client3, client4, client5, client6
VPN_TYPE="client2"
VPN_SERVER_IP_ADDRESS="192.168.10.61"

# set ip address for pi/internal nic
case "$VPN_TYPE" in
	server)
		ip_address_external_nic="$VPN_SERVER_IP_ADDRESS"
		;;
	client1)
		ip_address_external_nic="192.168.10.62"
		;;
	client2)
		ip_address_external_nic="192.168.10.63"
		;;
	client3)
		ip_address_external_nic="192.168.10.64"
		;;
	client4)
		ip_address_external_nic="192.168.10.65"
		;;
	client5)
		ip_address_external_nic="192.168.10.66"
		;;
	client6)
		ip_address_external_nic="192.168.10.67"
		;;

esac


# ip address for usb/internal nic
ip_address_internal_nic="192.168.1.70"

