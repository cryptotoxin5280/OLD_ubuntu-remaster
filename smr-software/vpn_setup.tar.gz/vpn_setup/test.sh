#!/bin/bash
current_dir=$(pwd)
script_dir=$(dirname $0)
#echo $current_dir
#echo $script_dir
total_dir=$current_dir'/'$script_dir

echo "Install Directory=$total_dir"

#load in defaults from config file
. $total_dir/installConfig.sh


# set vpn config files
echo "set up vpn config files"
if [[ $VPN_TYPE = "server" ]]
then
        #change values in iptablesConfig.sh
	sed -i "s?<VPN_TYPE>?$VPN_TYPE?g"  "$total_dir"/openvpn/server/iptablesConfig.sh
	sed -i "s?<VPN_SERVER_IP_ADDRESS>?$VPN_SERVER_IP_ADDRESS?g" "$total_dir"/openvpn/server/server.conf
	# copy all files to /etc/openvpn directory
	sudo cp -r -f "$total_dir"/openvpn/server /etc/openvpn
	#copy conf file to directory to autostart on boot
	sudo cp -r -f  /etc/openvpn/server/server.conf /etc/openvpn
	
else
	#change values in client.conf
	sed -i "s?<VPN_TYPE>?$VPN_TYPE?g" "$total_dir"/openvpn/client/client.conf
	sed -i "s?<VPN_SERVER_IP_ADDRESS>?$VPN_SERVER_IP_ADDRESS?g" "$total_dir"/openvpn/client/client.conf
	#change values in iptablesConfig.sh
	sed -i "s?<VPN_TYPE>?$VPN_TYPE?g"  "$total_dir"/openvpn/client/iptablesConfig.sh
        # copy all files to /etc/openvpn directory
	sudo cp -r -f "$total_dir"/openvpn/client /etc/openvpn
	#copy conf file to directory to autostart on boot
	sudo cp -r -f  /etc/openvpn/client/client.conf /etc/openvpn
fi


